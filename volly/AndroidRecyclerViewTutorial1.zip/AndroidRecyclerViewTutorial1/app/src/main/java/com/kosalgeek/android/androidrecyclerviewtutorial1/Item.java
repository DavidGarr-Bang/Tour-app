package com.kosalgeek.android.androidrecyclerviewtutorial1;


import java.io.Serializable;

public class Item implements Serializable {

    public int id;

    public String text;

    public String img;
}
